CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Structure
 * Installation
 * Libraries
 * Entities
 * Usage
 * Views Integration
 * Images
 * Tests


 INTRODUCTION
------------

Maintainer: Zenlan http://drupal.org/user/520924
Sandbox: http://drupal.org/sandbox/zenlan/1512290
Demo: http://www.zenlan.com/adlibtools
Git: http://git.drupal.org/sandbox/zenlan/1512290.git 7.x-1.x

Adlibtools is a Drupal 7 (only) module that provides a box of tricks for
retrieving and integrating data stored in an Adlib database using the Adlib API.
See http://api.adlibsoft.com/site/api

The original concept was to build a toolbox for use in building custom modules
rather than an off-the-shelf solution to Adlib data integration.

In the toolbox are entities, admin ui, libraries and views.
At this early stage the roadmap could take any direction, depending on the
use-cases that turn up.

Acknowledgments to the Entity, Views and Search API modules for inspiration and
some code snippets.

Readonly access to Adlib data is provided
Data is fetched from a remote server on demand and is not stored or cached
locally.
Writing to an Adlib data store is not supported.
Adlib sessions are not used.


 STRUCTURE
------------

adlibtools - main functionality that uses Drupal 7 entities and the Entity API
module to manage the required entities.

adlibtools/includes - 'library' units: Adlib request builder, response parser,
query builder

adlibtools/views - views integration units

adlibtools/test - Drupal Simpletest unit/web test cases


 INSTALLATION
------------

The .install script uses hook_schema to declare a table named 'adlibtools'
which is used to store adlib definitions.
A default record is created on installation, this record is a sample only and
not necessary for the module to function.
The table is deleted on uninstallation.


 LIBRARIES
------------

Custom libraries for building Adlib requests and parsing Adlib responses are
included.
These units are module-agnostic but not Drupal-agnostic.


 ENTITIES
------------

The module defines two distinct types of entities, "Adlibtools" entities and
"Adlib" entities.

The first, Adlibtools, is a CRUD entity used in the management of the records
stored in the adlibtools table.
It makes use of the Entity API 'Admin UI' functionality to provide the
management user interface.
Each record in the adlibtools table is declared as both a bundle of the
Adlibtools entity and as an entity in it's own right.
The bundle is used by Adlibtools for managing the CRUD entity.

The separate Adlib entities are available for use by other modules such as
Views. Adlib entities are hybrids in that they use a common controller and a
class populated with properties fetched on request.


 USAGE
------------

A user defines ('adds') an Adlib entity via admin/structure/adlibtools by
providing a name, label, unique key and URL (database optional).

If "Fetch Adlib fields" is checked, on save Adlibtools will attempt to connect
to the Adlib server API to retrieve the metadata for the given (or default)
Adlib database.

The metadata is converted to Drupal entity properties and both raw and
converted properties are stored in the adlibtools table.

Both the metadata and properties are displayed when editing the definition.
Check one or more properties to make them 'searchable' by the 'Search' field in
the Search page of the default View.  If none of these properties are checked
the search field will be unable to search.

The definition of each entity declared by Adlibtools can be inspected via
admin/config/search/adlibtools/properties, along with miscellaneous other
information about the module.

'Adlib Item Debug Page' lets you view the raw data for a single Adlib priref at
adlibtools/debug/%entity_type/%id for a valid %entity_type and %id


 VIEWS INTEGRATION
------------

Declares custom query plugin, and field/filter/argument handlers.

Every property/field of an Adlib entity with 'isIndexed' set to 'True' is
declared in views_data as a filter and argument. All fields are available for
display. In this way it is possible to build a page using a number of filters.

A special 'Search' field is also declared, similar to Search API's
'Search', it will search fields as defined in it's options form.
Fields that are checked and saved using the Adlibtools Admin UI edit page will
be available to the 'Search' field in it's options form.

Each time a new Adlib entity is created, hook_views_default_views creates a
default view for it. This view includes a fulltext search page, filter search
page and a single item page.

Adlib groups are now handled with the AdlibtoolsViewsHandlerFieldGroup class,
inheriting from the AdlibtoolsViewsHandlerFieldMultivalue class.

Note: 'group' here refers to Adlib groups and not Views grouping
(which is not implemented).

Every field, grouped or ungrouped, is available to Views using the
AdlibtoolsViewsHandlerFieldMultivalue class and can be used alongside or
instead of the group fields.

This handler provides a 'Render one' option which allows for the output of only
the first value in an array of values and should be used when rewriting as
links or images.

It also provides a 'List type' option that defaults to unordered list
for multi-valued fields.

Adlib entity configuration now creates a special Views data 'field' for each
Adlib group and assigns a special Views handler,
AdlibtoolsViewsHandlerFieldGroup
(inherited from AdlibtoolsViewsHandlerFieldMultivalue).
This field aggregates it's member fields and uses 'tokens' to format the output.

The default views provide basic examples, e.g. you can inspect the rewrite rule
for the adlibtest default view field 'Dimension Group' and see that each member
field is listed alongside a label:

dimension.type: [dimension.type]
dimension.type.lref: [dimension.type.lref]
dimension.value: [dimension.value]
dimension.unit: [dimension.unit]
dimension.unit.lref: [dimension.unit.lref]
dimension.precision: [dimension.precision]
dimension.part: [dimension.part]
dimension.notes: [dimension.notes]

This rewrite will produce an unformatted block of values with labels e.g.

Dimension Group:
<ul>
  <li>dimension.type: height<br />
      dimension.type.lref: 6<br />
      dimension.value: 89<br />
      dimension.unit: mm<br />
      dimension.unit.lref: 18<br />
      dimension.precision: <br />
      dimension.part: <br />
      dimension.notes: oval
  </li>
  <li>dimension.type: width<br />
      dimension.type.lref: 7<br />
      dimension.value: 71<br />
      dimension.unit: mm<br />
      dimension.unit.lref: 18<br />
      dimension.precision: <br />
      dimension.part: <br />
      dimension.notes: oval
  </li>
</ul>

Note that it cannot hide these labels for empty values.

This rewrite could be altered e.g.

[dimension.type]: [dimension.value] [dimension.unit]

which would then output :

Dimension Group:
<ul>
  <li>height: 89 mm</li>
  <li>width: 71 mm</li>
</ul>

Note: Only group fields are used to create the default views, in order to
reduce the risk of loading potentially hundreds of fields and field handlers.

While the default views act as examples and demonstrations, it is advisable to
create a new view for production rather than rely on them. Reverting a default
view would cause all of your changes to be overwritten.

Stuff not yet implemented:

* Views grouping
* search field in conjunction with other filters
* chaining field options e.g. output as image linked to entity

 IMAGES
------------

The custom field handler includes a 'rewrite_image' option that allows you to
"Rewrite this field as image."

You may manipulate the field's value in one of two ways.

1) Leave the Subject field blank and specify a replacement string containing
this field's own token (no other tokens will work); e.g.

  Subject: ''
  Replacement: http://test2.adlibsoft.com/api/wwwopac.ashx?
  command=getcontent&server=adlibimages&value=[reproduction.reference]
  Data: OP219.jpg
  Result: <img src="http://test2.adlibsoft.com/api/wwwopac.ashx?
  command=getcontent&server=adlibimages&value=OP219.jpg"/>

2) In the Subject field, specify a Regular Expression containing a named group
called 'token'. In the Replacement field use [token] as the placeholder for
the value returned in the named group; e.g.

  Subject: \.\.\\\.\.\\dat\\collectie\\images\\(?P<token>.)
  Replacement: http://ahm.adlibsoft.com/ahmimages/[token]
  Data: ..\..\DAT\Collectie\images\S_KA_13684_000.jpg
  Result = <img src="http://ahm.adlibsoft.com/ahmimages/S_KA_13684_000.jpg"/>


 TESTS
------------

The test cases make use of the test API service provided by Adobe at
http://test2.adlibsoft.com/api/wwwopac.ashx?database=collect.inf
Occassionally this service goes offline, should the test results report failure
to find host, check the URL in a browser to confirm
A different test service could be used by editing the defines at the top of
adlibtools.module.
define('ADLIBTOOLS_TEST_HOST', 'test2.adlibsoft.com/api');
define('ADLIBTOOLS_TEST_HANDLER', 'wwwopac.ashx');
define('ADLIBTOOLS_TEST_DATABASE', 'collect.inf');


 KNOWN ISSUES
------------

Highlight tags in JSON output
  http://drupal.org/node/1563556
